<?php

namespace Custom\Chatbot\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Pandit;
use Custom\Chatbot\helpers\Helper;
use Custom\Chatbot\Models\ChatAnswer;
use Custom\Chatbot\Models\ChatQuestion;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Redis;

class ChatController extends Controller
{

    public function index(){
        return Blade::compileString('{!! Custom\Chatbot\helpers\Helper::render_my_view() !!}');
    }

    public function getAnswer(Request $request){
        if(Redis::client()->exists('question'.$request->question_id)){
            return json_decode(Redis::client()->get('question'.$request->question_id));
        }
        $data = ChatAnswer::where("question_id",(int)$request->question_id)->first("answers");
        Redis::client()->set('question'.$request->question_id,$data);
        return $data;
    }
}
