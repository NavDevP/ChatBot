<?php

namespace Custom\Chatbot\Models;

use App\Models\Pivot\BlogSeo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Support\Str;

class ChatAnswer extends Model
{
    use HasFactory;

    protected $fillable = ["answers","question_id"];

    public function question(): HasOne
    {
        return $this->hasOne(static::class,"id","question_id");
    }

}
