<?php

namespace Custom\Chatbot\Models;

use App\Models\Pivot\BlogSeo;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Support\Str;

class ChatQuestion extends Model
{
    use HasFactory;

    protected $fillable = ["question","status","question_type"];

    public function answer(): HasOne
    {
        return $this->hasOne(ChatAnswer::class,"question_id","id");
    }

    public function setStatusAttribute(): int
    {
        return 1;
    }
}
