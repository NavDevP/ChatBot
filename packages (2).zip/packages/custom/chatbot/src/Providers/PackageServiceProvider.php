<?php

namespace Custom\Chatbot\Providers;

use Custom\Chatbot\Controllers\ChatController;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;

class PackageServiceProvider extends ServiceProvider
{
    public function boot()
    {
        $this->loadViewsFrom(__DIR__.'/../resources/views', 'custom-chatbot');
        $this->loadRoutesFrom(__DIR__.'/../routes/web.php');
        $this->initBladeDirectives();
        $this->initPublishes();
    }

    public function register()
    {
    }

    protected function initBladeDirectives(){
        Blade::directive('chatbot', [ChatController::class,'index']);
    }

    protected function initPublishes(){
        $this->publishes([
            __DIR__.'/../database/migrations/' => database_path('migrations')
        ], 'migrations');
        $this->publishes([
            __DIR__.'/../database/seeders/' => database_path('seeders')
        ], 'seeders');
    }
}
