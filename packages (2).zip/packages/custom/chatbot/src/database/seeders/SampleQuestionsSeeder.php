<?php

use App\Models\Categories;
use App\Models\Seo;
use Carbon\Carbon;
use Custom\Chatbot\Models\ChatAnswer;
use Custom\Chatbot\Models\ChatQuestion;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class SampleQuestionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        if(ChatQuestion::count() > 0){
            return;
        }else {
            ChatQuestion::insert([[
                "question" => "Who is Vedic Astrologer Kapoor?",
                "status" => 1
            ]]);
            ChatAnswer::insert([[
                'question_id' => 1,
                "answers" => "An Astrologer and Pandit",
                "status" => 1
            ]]);
        }
        $this->command->info('Sample Questions Seeded Successfully!');
    }
}
