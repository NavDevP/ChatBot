<?php
namespace Custom\Chatbot\helpers;

use Custom\Chatbot\Models\ChatQuestion;

class Helper
{
    public static function render_my_view()
    {
        $questions = ChatQuestion::all();
        return view("custom-chatbot::chatbot",compact('questions'))->render();
    }
}
