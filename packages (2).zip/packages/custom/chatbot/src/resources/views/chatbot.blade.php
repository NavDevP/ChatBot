@include('custom-chatbot::style')
<div class="chat-output" id="chat-output">
    <div class="user-message">
        <div class="message">
            <i class="fas fa-comment icon-default"></i>
            <i class="fas fa-times icon-click" style="display:none"></i>
        </div>
    </div>
    <div class="popup">
        <div class="header">Ask Question <span style="float:right">
                <i class="fas fa-times-circle close-icon" style="cursor:pointer"></i>
            </span></div>
        <div class="body">
            <div class="chat_form" style="display: none">
                <p>Hii Please fill out the form to submit your question to the admin.</p>
                <div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="chat_name" placeholder="Name">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="chat_email" placeholder="Email">
                    </div>
                    <div class="form-group">
                        <textarea class="form-control" name="text" id="chat_message" rows="4" placeholder="Message"></textarea>
                    </div>
                    <div class="form-group">
                        <button type="button" id="chat_submit" class="btn">Submit</button>
                    </div>
                </div>
                <div class="back_to">
                    <a href="javascript:void(0)"><span><i class="fas fa-backward"></i></span> Back to Questions</a>
                </div>
            </div>
            <div class="chat_listing">
                <div class="scrollBarNew">
                    <ul class="" id="chat_question_list">
                        <li>
                            <div class="sphead">Questions</div>
                            <div class="gquestios_grid">
                               @foreach($questions as $question)
                                 <span class="badge questionB" data-id="{{$question->id}}">{{$question->question}}</span>
                               @endforeach
                            </div>
                            <div style="text-align-last: center;">
                                Not able to find your question?
                                <a href="javascript:void(0)" id="ask_manually">Ask Question</a>
                            </div>
                        </li>
                        <!-- li>
                            <div class="left_user gradent_bg">
                                Welcome to our site, if you need help simply read to the message. we are online  and ready to help.
                            </div>
                        </li>
                        <li class="clear">
                            <div class="right_user">
                                <div class="chat_text">
                                    Hii, I am Online back
                                </div>
                            </div>
                        </li -->

                    </ul>

                    <ul id="loader" style="display:none;">
                        <li>
                            <div class="left_user gradent_bg">

                                <div class="typing">
                                    <div class="dot"></div>
                                    <div class="dot"></div>
                                    <div class="dot"></div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>

            </div>
            <div class="chat_step" style="display: none">
                <h4>Your Question has been Submitted</h4>
                <p>It will take upto 4 hours to get your response</p>
                <p>Please rate your experience:</p>
                <div class="chat_bnt">
                    <button class="green_bnt">
                        <div class="cricle_thumb"><i class="far fa-thumbs-up"></i></div>
                        <span>Great</span>
                    </button>
                    <button class="red_bnt">
                        <div class="cricle_thumb"><i class="far fa-thumbs-down"></i></div>
                        <span>Bad</span>
                    </button>
                </div>
                <div class="back_to">
                    <a href="javascript:void(0)"><span><i class="fas fa-backward"></i></span> Back to Questions</a>
                </div>
            </div >
        </div>
    </div>
</div>
@include('custom-chatbot::script')
