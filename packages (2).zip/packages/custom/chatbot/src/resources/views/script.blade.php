<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(".close-icon").click(function () {
        if ($(".popup").is(":visible")) {
            $(".popup").hide();
            $(".icon-default").show();
            $(".icon-click").hide();
        } else {
            $(".popup").show();
            $(".icon-default").hide();
            $(".icon-click").show();
        }

    })
    $("#chat-output").on("click", (e) => {
        if (e.target.className === "chat-output" || e.target.className === "message" || e.target.className === "fas fa-comment icon-default" ||  e.target.className === "fas fa-times icon-click") {
            if ($(".popup").is(":visible")) {
                $(".popup").hide();
                $(".icon-default").show();
                $(".icon-click").hide();
            } else {
                $(".popup").show();
                $(".icon-default").hide();
                $(".icon-click").show();
            }
        }
    });

    let working = false;
    $("#chat_question_list").on("click", ".questionB", (e) => {
        var element = $(e.currentTarget);
        if (element.data("clicked") === 1) {
            return;
        }
        if (working) {
            return;
        }
        working = true;
        $("#chat_question_list").append('<li class="clear"><div class="right_user"><div class="chat_text">' + element.text() + '</div></div></li>');

        e.currentTarget.style.background = "#d21e2b";
        e.currentTarget.style.color = "#fff";
        element.attr('data-clicked', '1');
        $("#loader").show();
        $(".scrollBarNew").animate({ scrollTop: $(".scrollBarNew")[0].scrollHeight}, 1000)
        $.ajax({
            url: "{{route('get-answer')}}",
            method: "POST",
            data: {
                question_id: element.data('id'),
                _token: "{{csrf_token()}}"
            },
            success: function (res) {
                working = false;
                $("#loader").hide();
                $("#chat_question_list").append(' <li><div class="left_user gradent_bg">' + res.answers + '</div></li>');
                $(".scrollBarNew").animate({ scrollTop: $(".scrollBarNew")[0].scrollHeight}, 1000)
            },
            error: function (err) {
                working = false;
                console.error(err)
            }
        })
    });
    $("#ask_manually").click(function () {
        $(".chat_form").show();
        $(".chat_listing").hide();
        $(".chat_step").hide();
    })

    $("#chat_submit").click(function () {
        var name = $("#chat_name").val()
        var email = $("#chat_email").val()
        var message = $("#chat_message").val()
        if(name === "" && email === "" && message === ""){ alert("Please fill all the fields"); }
        else {
            $(this).prop("disabled",true).text("Submitting...");
            setTimeout(function () {
                $(".chat_form").hide();
                $(".chat_listing").hide();
                $(".chat_step").show();
                $("#chat_submit").prop("disabled",false).text("Submit");
                $("#chat_name").val("")
                $("#chat_email").val("")
                $("#chat_message").val("")
            }, 1500);
        }
    })

    $(".back_to a").click(function () {
        $(".chat_form").hide();
        $(".chat_listing").show();
        $(".chat_step").hide();
    })

</script>
