<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/fontawesome.min.css">
<style>
    .chat-output {
        position: fixed;
        right: 20px;
        border-radius: 100px;
        z-index: 9999;
        width: 65px;
        height: 65px;
        bottom: 20px;
        flex: 1;
        cursor: pointer;
        padding: 20px;
        align-items: center;
        display: flex;
        background: #d21e2b;
        flex-direction: column;
    }

    .chat-output > div {
        margin: 0 0 20px 0;
    }

    .user-message {
        /*.message {*/
        /*    background: #0FB0DF;*/
        /*    color: white;*/
        /*}*/
    }

    /*.bot-message {*/
    /*    text-align: right;*/
    /*    .message {*/
    /*        background: #eee;*/
    /*    }*/
    /*}*/

    .message {
        display: inline-block;
        /*padding: 12px 20px;*/
        border-radius: 10px;
    }

    .chat-input {
        padding: 20px;
        background: #eee;
        border: 1px solid #ccc;
        border-bottom: 0;
    }

    .user-input {
        width: 100%;
        font-size: 2rem;
        border: 1px solid #ccc;
        border-radius: 4px;
        padding: 8px;
    }

    .message i {
        color: white;
        font-size: 25px;
    }

    .popup {
        display: none;
        cursor: default !important;
        right: 0;
        border-radius: 10px;
        width: 350px;
        bottom: 70px;
        position: absolute;
        background: white;
        box-shadow: 2px 2px 30px #686868;
    }

    .popup .header {
        background: #d21e2b;
        padding: 8px 10px;
        height: 40px;
        border-top-right-radius: 8px;
        border-top-left-radius: 8px;
        color: white;
    }

    .popup .body {
        padding: 15px 8px 15px 15px;
        height: 360px;
    }
    .chat_listing {
        height: 100%;
    }
    .chat_listing .scrollBarNew {
        height: 100%;
    }
    .scrollBarNew{
        overflow: auto;
        padding-right: 10px;
    }
    .scrollBarNew::-webkit-scrollbar {width: 6px;}
    .scrollBarNew::-webkit-scrollbar-track {background: #d21e2b;border-radius: 10px;}
    .scrollBarNew::-webkit-scrollbar-thumb {background: #000;border-radius: 10px;height: 10px;}

    .chat_form p {
        text-align: center;
        font-size: 12px;
        font-weight: 500;
        color: #000;
        margin-bottom: 15px;
    }

    .chat_form .form-group {
        margin-top: 15px;
    }

    .chat_form .form-group input {
        height: 35px;
        font-size: 12px;
    }
    .chat_form .form-group textarea {
        font-size: 12px;
    }

    .back_to {
        position: absolute;
        bottom: 0;
        margin: 15px;
        left: 100px;
        font-size: 14px;
    }
    .back_to a{
        color: #d21e2b;
    }

    .chat_form .form-group select {
        width: 100%;
        border: 1px solid #ced4da;
        border-radius: 5px;
        padding: .375rem .75rem;
        font-size: 12px;
        height: 35px;
        outline: none;
    }

    .chat_form .form-group button {
        background-color: #d21e2b;
        color: #fff;
        font-size: 12px;
        max-width: 200px;
        margin: 0 auto;
        display: block;
    }

    .chat_listing li {
        margin: 8px 0px;
        font-size: 12px;
    }
    .chat_listing li > div {
        padding: 5px 10px;
    }
    .gradent_bg {
        background-color: #d21e2b;
        color: #fff;
        display: inline-block;
        border-radius: 0px 10px 10px 10px;
    }
    .right_user {
        float: right;
        padding: 0 !important;
    }
    .chat_text {
        padding: 5px 10px;
        box-shadow: 1px 1px 5px #ccc;
        border-radius: 10px 0 10px 10px;
    }



    .clear::after {
        content: "";
        clear: both;
        display: table;
    }
    .clear{
        clear: both;
    }
    .typing {
        align-items: center;
        display: flex;
        height: 17px;
    }
    .typing .dot {
        animation: mercuryTypingAnimation 1.8s infinite ease-in-out;
        background-color: #fff ;
        border-radius: 50%;
        height: 7px;
        margin-right: 4px;
        vertical-align: middle;
        width: 7px;
        display: inline-block;
    }
    .typing .dot:nth-child(1) {
        animation-delay: 200ms;
    }
    .typing .dot:nth-child(2) {
        animation-delay: 300ms;
    }
    .typing .dot:nth-child(3) {
        animation-delay: 400ms;
    }
    .typing .dot:last-child {
        margin-right: 0;
    }

    @keyframes mercuryTypingAnimation {
        0% {
            transform: translateY(0px);
            background-color:#fff;
        }
        28% {
            transform: translateY(-7px);
            background-color:#fff;
        }
        44% {
            transform: translateY(0px);
            background-color: #fff;
        }
    }


    .chat_step {
        text-align: center;
    }
    .chat_step h4 {
        font-size: 16px;
        font-weight: 600;
        margin-bottom: 10px;
    }
    .chat_step p {
        font-size: 12px;
        margin-bottom: 20px;
    }
    .chat_bnt {
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .chat_bnt button {
        border: none;
        background: transparent;
        outline: none;
        cursor: pointer;
        margin: 0 10px;
    }
    .chat_bnt button .cricle_thumb {
        width: 45px;
        height: 46px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        font-size: 18px;
        color: #fff;
    }

    button.green_bnt .cricle_thumb{
        background-color: green;
    }
    button.red_bnt .cricle_thumb{
        background-color: #d21e2b;
    }
    .chat_bnt span {
        display: block;
        font-size: 14px;
        margin-top: 10px;
    }
    button.green_bnt span{
        color: green;
    }
    button.red_bnt span{
        color: #d21e2b;
    }

    .gquestios_grid {
        padding: 10px 0px !important;
        margin: 0px -2px;
    }
    .gquestios_grid span.badge {
        border: 1px solid #d21e2b;
        font-size: 12px;
        cursor: pointer;
        color: #d21e2b;
        display: inline-block;
        padding: 8px;
        margin: 2px;
    }
    .sphead{
        text-align: center;
        font-size: 16px;
        font-weight: 600;
    }

</style>
