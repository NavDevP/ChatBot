<?php

use Custom\Chatbot\Controllers\ChatController;



Route::post("get_answer",[ChatController::class,'getAnswer'])->name('get-answer');
